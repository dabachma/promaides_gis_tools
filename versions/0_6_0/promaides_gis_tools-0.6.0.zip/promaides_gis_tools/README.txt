Store the unziped directory into your QGIS-plugin folder;
e.g. c:\Users\Daniel Bachmann\AppData\Roaming\QGIS\QGIS3\profiles\default\

Then it should be avaialble after a restart of QGIS