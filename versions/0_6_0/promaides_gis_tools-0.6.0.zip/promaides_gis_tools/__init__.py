

def classFactory(iface):
    from .promaides_tools import PromaidesToolbox
    return PromaidesToolbox(iface)
