Detailed information are provided in: https://promaides.h2.de

Information about the plugins: https://promaides.myjetbrains.com/youtrack/articles/PMDP-A-6/Plug-ins

If you have any questions or remarks or did you find a bug please contact daniel.bachmann@h2.de

Have fun!!
